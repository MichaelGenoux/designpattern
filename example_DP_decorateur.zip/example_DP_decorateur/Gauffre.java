package example_DP_decorateur;

public class Gauffre extends Dessert {
	public Gauffre() {
		setNom("Gauffre");
		setPrix(5.00);
	}
}
