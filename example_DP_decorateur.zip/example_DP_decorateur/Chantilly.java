package example_DP_decorateur;

/* Classe Chantilly permet d'impl�menter une 
 * d�coration pour nos dessert  
 */

public class Chantilly extends DecorateurIngredient {
	
	/* Le constructeur prend en param�tre le dessert � d�corer
	 * et est stock� dans l'attribue de la classe DecorateurIngredient 
	 */
	public Chantilly(Dessert dessADec) {
		dessert = dessADec;
	}
	
	// Redefinition des m�thodes de DecorateurIngredient
	public String getNom() {
		return dessert.getNom()+ " + sup = chantilly";
	}
	
	public double getPrix() {
		return dessert.getPrix()+1.00;
	}
}
