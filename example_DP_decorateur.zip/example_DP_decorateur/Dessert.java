package example_DP_decorateur;

import java.text.NumberFormat;

public abstract class Dessert
{
     private String nom;
     private double prix;
     
     // Accesseurs en lecture pour le libell� et le prix.
     public String getNom()
     {
             return nom;
     }
     
     public double getPrix()
     {
             return prix;
     }
     
     // Accesseurs en �criture pour le libell� et le prix.
     protected void setNom(String nom)
     {
             this.nom = nom;
     }
     
     protected void setPrix(double prix)
     {
             this.prix = prix;
     }
     
     // M�thode utilis�e pour l'affichage d'un dessert.
     public String toString()
     {
             NumberFormat format=NumberFormat.getInstance();
             format.setMinimumFractionDigits(2);// 2 chiffres apr�s la virgule suffisent pour l'affichage.
             return getNom()+" : "+format.format(getPrix())+"�";
     }
}