
package example_DP_decorateur;

public class Main {
	
	public static void main(String [] args) {
		
		/* Notre serveur souhaite :
			- d1 => une cr�pe au sucre
			- d2 => une gauffre au chocolat et � la chantilly
			- d3 => un snicker
		*/
		
		System.out.println("Commande : \n - cr�pe au sucre \n - gauffre au chocolat et chantilly \n - snicker \n");
		
		Dessert d1 = new Crepe();
		d1 = new Sucre(d1);
		System.out.println(d1);
		
		Dessert d2 = new Gauffre();
		d2 = new Chocolat(d2);
		d2 = new Chantilly(d2);
		System.out.println(d2);
		
		Dessert d3 = new Snicker();
		d3 = new Sucre(d3);
		System.out.println(d3);
	}
}