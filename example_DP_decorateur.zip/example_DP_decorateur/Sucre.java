package example_DP_decorateur;

public class Sucre extends DecorateurIngredient {
	
	public Sucre (Dessert dessADec) {
		dessert = dessADec;
	}
	
	public String getNom() {
		return dessert.getNom()+ " + sup = sucre";
	}
	
	public double getPrix() {
		return dessert.getPrix()+1.00;
	}
}
