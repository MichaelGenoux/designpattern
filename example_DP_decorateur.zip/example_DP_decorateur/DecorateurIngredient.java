package example_DP_decorateur;

/*
 *  Classe abstraite DecorateurIngredient, permet d'ajouter des ingredient 
 *  sur un objet de type Dessert
 */

public abstract class DecorateurIngredient extends Dessert {
	// Dessert � d�corer ; type protected pour eviter les acesseurs dans les classes filles
	Dessert dessert;
	
	// On redefinira de mani�re sp�cifique les accesseurs pour chaque ingr�dient
	public abstract String getNom();
	public abstract double getPrix();
}
