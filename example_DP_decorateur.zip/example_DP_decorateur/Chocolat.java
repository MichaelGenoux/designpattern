package example_DP_decorateur;

public class Chocolat extends DecorateurIngredient {
	
	public Chocolat (Dessert dessADec) {
		dessert = dessADec;
	}
	
	public String getNom() {
		return dessert.getNom()+ "  + sup = chocolat";
	}
	
	public double getPrix() {
		return dessert.getPrix()+1.00;
	}
}
