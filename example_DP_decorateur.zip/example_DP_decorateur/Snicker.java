package example_DP_decorateur;

public class Snicker extends Dessert {
	public Snicker() {
		setNom("Snicker");
		setPrix(1.50);
	}
}
