package example_DP_decorateur;

public class Crepe extends Dessert {
	public Crepe() {
		setNom("Crepe");
		setPrix(5.00);
	}
}
